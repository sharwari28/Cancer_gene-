
const home5GalleryData = [
    {
        id: 1,
        img: 'img/home5/gallery/gallery__thumb1.jpg',
        category: 'dental',
    },

    {
        id: 2,
        img: 'img/home5/gallery/gallery__thumb2.jpg',
        category: 'Neurology',
    },
    {
        id: 3,
        img: 'img/home5/gallery/gallery__thumb3.jpg',
        category: 'dental',
    },
    {
        id: 4,
        img: 'img/home5/gallery/gallery__thumb1.jpg',
        category: 'Neurology',
    },
    {
        id: 5,
        img: 'img/home5/gallery/gallery__thumb4.jpg',
        category: 'dental',
    },
    {
        id: 6,
        img: 'img/home5/gallery/gallery__thumb5.jpg',
        category: 'dental',
    },
    {
        id: 7,
        img: 'img/home5/gallery/gallery__thumb4.jpg',
        category: 'Neurology',
    },
    {
        id: 8,
        img: 'img/home5/gallery/gallery__thumb2.jpg',
        category: 'Surgery',
    },
    {
        id: 9,
        img: 'img/home5/gallery/gallery__thumb5.jpg',
        category: 'Surgery',
    },
    {
        id: 10,
        img: 'img/home5/gallery/gallery__thumb6.jpg',
        category: 'Surgery',
    },
    {
        id: 11,
        img: 'img/home5/gallery/gallery__thumb3.jpg',
        category: 'Medicin',
    },
    {
        id: 12,
        img: 'img/home5/gallery/gallery__thumb4.jpg',
        category: 'Medicin',
    },
    {
        id: 13,
        img: 'img/home5/gallery/gallery__thumb5.jpg',
        category: 'Medicin',
    },
    {
        id: 14,
        img: 'img/home5/gallery/gallery__thumb6.jpg',
        category: 'Medicin',
    },
]
export default home5GalleryData;