import React from 'react';
import Footer from '../../components/Shared/Footer';
import HomeHeader from '../Home/Home/HomeHeader/HomeHeader';
import ChartArea from './ChartArea/ChartArea';

const Chart = () => {
    return (
        <>
            {/* <HomeHeader/> */}
            <ChartArea/>
            {/* <Footer/> */}
        </>
    );
};

export default Chart;